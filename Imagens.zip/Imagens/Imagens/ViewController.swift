//
//  ViewController.swift
//  Imagens
//
//  Created by Usuário Convidado on 10/05/2018.
//  Copyright © 2018 Usuário Convidado. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ivTrapalhao: UIImageView!
    let trapalhoes = ["didi", "dede", "mussum", "zacarias"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ivTrapalhao.layer.cornerRadius = ivTrapalhao.frame.size.width/2
        ivTrapalhao.layer.borderWidth = 0
        ivTrapalhao.layer.borderColor = UIColor.blue.cgColor
    }

    @IBAction func changeBorder(_ sender: UISlider) {
        ivTrapalhao.layer.borderWidth = CGFloat(sender.value)
    }
    
    @IBAction func playAnimation(_ sender: UIButton) {
        var images: [UIImage] = []
        for number in 1...68{
            if let image = UIImage(named: "HomemAndando\(number).png"){
                images.append(image)
            }
        }
        
        //Tira a borda
        ivTrapalhao.layer.borderWidth = 0
        
        //Remove o arrendondamento
        ivTrapalhao.layer.cornerRadius = 0
        
        //Muda o aspecto
        ivTrapalhao.contentMode = .scaleAspectFit
        
        ivTrapalhao.animationImages = images
        ivTrapalhao.animationRepeatCount = 0
        ivTrapalhao.animationDuration = 2
        ivTrapalhao.startAnimating()
    }
    
    @IBAction func changeTrapalhao(_ sender: UISegmentedControl) {
        let imageName = trapalhoes[sender.selectedSegmentIndex]
        ivTrapalhao.image = UIImage(named: imageName)
    }
    
    
}

