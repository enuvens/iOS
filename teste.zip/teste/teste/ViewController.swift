//
//  ViewController.swift
//  teste
//
//  Created by Usuário Convidado on 19/04/2018.
//  Copyright © 2018 Usuário Convidado. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var tfWeight: UITextField!
    @IBOutlet weak var tfHeight: UITextField!
    @IBOutlet weak var lbResult: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    @IBAction func calculate(_ sender: Any) {
        
        guard let weight = Double(tfWeight.text!) else {return}
        guard let height = Double(tfHeight.text!) else {return}
        
        let (_, imc) = calculateIMC(weight: weight, height: height)
        lbResult.text = "O seu IMC é \(imc.rawValue)";
        
        view.endEditing(true);
    }
    
    func calculateIMC(weight: Double, height: Double) -> (value: Double, result: IMC) { let value = weight/(height*height)
        var result: IMC!
        switch value {
        case 0..<16:
            result = .thinness
        case 16..<18.5:
            result = .under
        case 18.5..<25:
            result = .ideal
        case 25..<30:
            result = .over
        default:
            result = .obesity
        }
        return (value, result)
    }
    

}

