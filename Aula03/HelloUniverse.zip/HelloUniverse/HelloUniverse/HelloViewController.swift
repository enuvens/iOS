//
//  HelloViewController.swift
//  HelloUniverse
//
//  Created by Usuário Convidado on 15/03/2018.
//  Copyright © 2018 FIAP. All rights reserved.
//

import UIKit

class HelloViewController: UIViewController {

    @IBOutlet weak var lbHello: UILabel!
    
    @IBAction func changeLabel(_ sender: Any) {
        lbHello.text = "Hello Universe"
    }
    
}
